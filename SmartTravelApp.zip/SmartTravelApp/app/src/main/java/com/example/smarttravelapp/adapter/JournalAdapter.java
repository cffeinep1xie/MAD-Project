package com.example.smarttravelapp.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.DBHelper;
import com.example.smarttravelapp.R;
import com.example.smarttravelapp.model.JournalEntry;

import java.util.ArrayList;

public class JournalAdapter extends RecyclerView.Adapter<JournalAdapter.ViewHolder> {

    private final Context context;
    private final ArrayList<JournalEntry> journalList;
    private final DBHelper dbHelper;

    public JournalAdapter(Context context,
                          ArrayList<JournalEntry> journalList,
                          DBHelper dbHelper) {

        this.context = context;
        this.journalList = journalList;
        this.dbHelper = dbHelper;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgJournal;
        TextView tvTitle, tvLocation, tvDate, tvDescription;
        ImageButton btnDelete, btnEdit;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgJournal = itemView.findViewById(R.id.imgJournal);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvDescription = itemView.findViewById(R.id.tvDescription);

            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.journal_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        JournalEntry entry = journalList.get(position);

        holder.tvTitle.setText(entry.getTitle());
        holder.tvLocation.setText(entry.getLocation());
        holder.tvDate.setText(entry.getDate());
        holder.tvDescription.setText(entry.getDescription());

        if (entry.getImage() != null && !entry.getImage().isEmpty()) {

            holder.imgJournal.setImageURI(Uri.parse(entry.getImage()));

        } else {

            holder.imgJournal.setImageResource(R.drawable.ic_photo);

        }

        // Delete Journal Entry

        holder.btnDelete.setOnClickListener(v -> {

            new AlertDialog.Builder(context)
                    .setTitle("Delete Memory")
                    .setMessage("Delete this journal entry?")
                    .setPositiveButton("Delete", (dialog, which) -> {

                        boolean deleted = dbHelper.deleteJournal(entry.getId());

                        if (deleted) {

                            int adapterPosition = holder.getAdapterPosition();

                            if (adapterPosition != RecyclerView.NO_POSITION) {

                                journalList.remove(adapterPosition);

                                notifyItemRemoved(adapterPosition);

                                notifyItemRangeChanged(adapterPosition,
                                        journalList.size());

                            }

                            Toast.makeText(context,
                                    "Memory Deleted",
                                    Toast.LENGTH_SHORT).show();

                        } else {

                            Toast.makeText(context,
                                    "Delete Failed",
                                    Toast.LENGTH_SHORT).show();

                        }

                    })

                    .setNegativeButton("Cancel", null)

                    .show();

        });

        // Edit button (coming later)

        holder.btnEdit.setOnClickListener(v ->

                Toast.makeText(context,
                        "Edit feature coming soon",
                        Toast.LENGTH_SHORT).show()

        );

    }

    @Override
    public int getItemCount() {
        return journalList.size();
    }

}
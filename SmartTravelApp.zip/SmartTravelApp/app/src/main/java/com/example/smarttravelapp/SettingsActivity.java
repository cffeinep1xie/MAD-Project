package com.example.smarttravelapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.materialswitch.MaterialSwitch;

public class SettingsActivity extends AppCompatActivity {

    private ImageButton btnBack;

    private MaterialSwitch switchNotifications;
    private MaterialSwitch switchPhotos;

    private LinearLayout layoutTheme;
    private LinearLayout layoutCity;
    private LinearLayout layoutClearData;
    private LinearLayout layoutAbout;
    private LinearLayout layoutRate;
    private LinearLayout layoutShare;

    private TextView txtTheme;
    private TextView txtCity;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        preferences = getSharedPreferences("Settings", MODE_PRIVATE);

        btnBack = findViewById(R.id.btnBack);

        switchNotifications = findViewById(R.id.switchNotifications);
        switchPhotos = findViewById(R.id.switchPhotos);

        layoutTheme = findViewById(R.id.layoutTheme);
        layoutCity = findViewById(R.id.layoutCity);
        layoutClearData = findViewById(R.id.layoutClearData);
        layoutAbout = findViewById(R.id.layoutAbout);
        layoutRate = findViewById(R.id.layoutRate);
        layoutShare = findViewById(R.id.layoutShare);

        txtTheme = findViewById(R.id.txtTheme);
        txtCity = findViewById(R.id.txtCity);

        btnBack.setOnClickListener(v -> finish());

        loadSettings();
        setupSwitches();
        setupClicks();
    }

    private void loadSettings() {

        switchNotifications.setChecked(
                preferences.getBoolean("notifications", true));

        switchPhotos.setChecked(
                preferences.getBoolean("photos", true));

        txtTheme.setText(
                preferences.getString("theme", "Ocean Blue"));

        txtCity.setText(
                preferences.getString("city", "Mumbai"));
    }

    private void setupSwitches() {

        switchNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {

            preferences.edit()
                    .putBoolean("notifications", isChecked)
                    .apply();

        });

        switchPhotos.setOnCheckedChangeListener((buttonView, isChecked) -> {

            preferences.edit()
                    .putBoolean("photos", isChecked)
                    .apply();

        });

    }

    private void setupClicks() {

        layoutTheme.setOnClickListener(v -> chooseTheme());

        layoutCity.setOnClickListener(v -> changeCity());

        layoutClearData.setOnClickListener(v -> clearData());

        layoutAbout.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, AboutActivity.class);
            startActivity(intent);
        });

        layoutRate.setOnClickListener(v ->

                Toast.makeText(
                        SettingsActivity.this,
                        "⭐⭐⭐⭐⭐\nThank you for using Smart Travel Companion!",
                        Toast.LENGTH_LONG
                ).show()

        );

        layoutShare.setOnClickListener(v -> {

            Intent intent = new Intent(Intent.ACTION_SEND);

            intent.setType("text/plain");

            intent.putExtra(Intent.EXTRA_SUBJECT,
                    "Smart Travel Companion");

            intent.putExtra(Intent.EXTRA_TEXT,

                    "🌍 Smart Travel Companion\n\n" +

                            "Plan trips ✈️\n" +
                            "Track your budget 💰\n" +
                            "Maintain travel journals 📖\n" +
                            "Explore nearby places 📍\n\n" +

                            "Developed using Android Studio.\n" +

                            "Travel smarter with Smart Travel Companion!");

            startActivity(Intent.createChooser(intent,
                    "Share using"));

        });

    }

    private void chooseTheme() {

        String[] themes = {
                "Ocean Blue",
                "Sunset Pink",
                "Lavender"
        };

        new AlertDialog.Builder(this)
                .setTitle("Choose Theme")
                .setItems(themes, (dialog, which) -> {

                    txtTheme.setText(themes[which]);

                    preferences.edit()
                            .putString("theme", themes[which])
                            .apply();

                    Toast.makeText(
                            SettingsActivity.this,
                            "Theme updated!",
                            Toast.LENGTH_SHORT
                    ).show();

                })
                .show();

    }

    private void changeCity() {

        EditText editText = new EditText(this);

        editText.setHint("Enter Home City");
        editText.setText(txtCity.getText().toString());

        new AlertDialog.Builder(this)
                .setTitle("Default Home City")
                .setView(editText)

                .setPositiveButton("Save", (dialog, which) -> {

                    String city = editText.getText().toString().trim();

                    if (!city.isEmpty()) {

                        txtCity.setText(city);

                        preferences.edit()
                                .putString("city", city)
                                .apply();

                        Toast.makeText(
                                SettingsActivity.this,
                                "Home city updated!",
                                Toast.LENGTH_SHORT
                        ).show();

                    }

                })

                .setNegativeButton("Cancel", null)
                .show();

    }

    private void clearData() {

        new AlertDialog.Builder(this)
                .setTitle("Clear All Data")
                .setMessage("This will permanently delete all trips, journals and profile information.\n\nContinue?")
                .setPositiveButton("Delete", (dialog, which) -> {

                    DBHelper db = new DBHelper(this);
                    ProfileDBHelper profileDB = new ProfileDBHelper(this);

                    db.deleteAllTrips();
                    db.deleteAllJournals();
                    profileDB.deleteProfile();

                    getSharedPreferences("Settings", MODE_PRIVATE)
                            .edit()
                            .clear()
                            .apply();

                    Toast.makeText(this,
                            "All app data cleared!",
                            Toast.LENGTH_SHORT).show();

                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}


package com.example.smarttravelapp.model;
public class Destination {

    private int image;
    private String name;
    private String description;

    public Destination(int image, String name, String description) {
        this.image = image;
        this.name = name;
        this.description = description;
    }

    public int getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
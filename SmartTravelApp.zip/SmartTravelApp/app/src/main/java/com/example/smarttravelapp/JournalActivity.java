package com.example.smarttravelapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.adapter.JournalAdapter;
import com.example.smarttravelapp.model.JournalEntry;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashSet;

public class JournalActivity extends AppCompatActivity {

    RecyclerView rvJournal;
    FloatingActionButton fabAddJournal;

    LinearLayout layoutEmpty;

    TextView tvMemoryCount, tvPlacesCount;

    ArrayList<JournalEntry> journalList;

    JournalAdapter adapter;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journal);

        rvJournal = findViewById(R.id.rvJournal);
        fabAddJournal = findViewById(R.id.fabAddJournal);

        layoutEmpty = findViewById(R.id.layoutEmpty);

        tvMemoryCount = findViewById(R.id.tvMemoryCount);
        tvPlacesCount = findViewById(R.id.tvPlacesCount);

        dbHelper = new DBHelper(this);

        journalList = new ArrayList<>();

        rvJournal.setLayoutManager(new LinearLayoutManager(this));

        loadJournal();

        fabAddJournal.setOnClickListener(v -> {

            Intent intent = new Intent(
                    JournalActivity.this,
                    AddJournalActivity.class);

            startActivity(intent);

        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        loadJournal();
    }

    private void loadJournal() {

        journalList.clear();

        Cursor cursor = dbHelper.getAllJournalEntries();

        HashSet<String> places = new HashSet<>();

        if (cursor.moveToFirst()) {

            do {

                JournalEntry entry = new JournalEntry(

                        cursor.getInt(0),

                        cursor.getString(1),

                        cursor.getString(2),

                        cursor.getString(3),

                        cursor.getString(4),

                        cursor.getString(5)

                );

                journalList.add(entry);

                places.add(entry.getLocation());

            }

            while (cursor.moveToNext());

        }

        cursor.close();

        adapter = new JournalAdapter(
                this,
                journalList,
                dbHelper
        );

        rvJournal.setAdapter(adapter);

        tvMemoryCount.setText(String.valueOf(journalList.size()));

        tvPlacesCount.setText(String.valueOf(places.size()));

        if(journalList.isEmpty()){

            layoutEmpty.setVisibility(View.VISIBLE);

            rvJournal.setVisibility(View.GONE);

        }

        else{

            layoutEmpty.setVisibility(View.GONE);

            rvJournal.setVisibility(View.VISIBLE);

        }

    }

}
package com.example.smarttravelapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.example.smarttravelapp.model.Profile;

public class CreateProfileActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etCity, etBio;
    private MaterialButton btnSaveProfile;
    private ImageButton btnBack;

    private ProfileDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_profile);

        dbHelper = new ProfileDBHelper(this);

        SharedPreferences preferences =
                getSharedPreferences("UserSession", MODE_PRIVATE);

        String loggedInEmail =
                preferences.getString("loggedInEmail", "");
        Toast.makeText(this,
                "Email = " + loggedInEmail,
                Toast.LENGTH_LONG).show();

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);

        if (!loggedInEmail.isEmpty()) {
            etEmail.setText(loggedInEmail);
            etEmail.setEnabled(false); // Lock it only if pre-filled from session
        } else {
            etEmail.setEnabled(true);  // Allow user to enter email if session email is missing
        }
        etPhone = findViewById(R.id.etPhone);
        etCity = findViewById(R.id.etCity);
        etBio = findViewById(R.id.etBio);

        btnSaveProfile = findViewById(R.id.btnSaveProfile);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        btnSaveProfile.setOnClickListener(v -> {

            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String city = etCity.getText().toString().trim();
            String bio = etBio.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || city.isEmpty()) {

                Toast.makeText(this,
                        "Please fill all required fields.",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            Profile profile = new Profile(
                    name,
                    email,
                    phone,
                    city,
                    bio
            );

            boolean success;

            if (dbHelper.profileExists(loggedInEmail)) {
                dbHelper.updateProfile(profile, loggedInEmail);
                success = true;
            } else {
                success = dbHelper.saveProfile(profile, loggedInEmail);
            }

            if (success) {

                Toast.makeText(this,
                        "Profile Saved!",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(CreateProfileActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();

            } else {

                Toast.makeText(this,
                        "Failed to save profile.",
                        Toast.LENGTH_SHORT).show();
            }

        });

    }
}
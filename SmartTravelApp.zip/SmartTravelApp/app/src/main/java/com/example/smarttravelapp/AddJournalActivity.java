package com.example.smarttravelapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.Calendar;

public class AddJournalActivity extends AppCompatActivity {

    private ImageView imgPreview;
    private EditText etTitle, etLocation, etDate, etDescription;
    private MaterialButton btnSaveJournal;
    private MaterialCardView cardPhoto;

    private DBHelper dbHelper;

    private String imageUri = "";

    private final ActivityResultLauncher<Intent> imagePickerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {

                        if (result.getResultCode() == RESULT_OK
                                && result.getData() != null) {

                            Uri uri = result.getData().getData();

                            if (uri != null) {

                                imageUri = uri.toString();

                                imgPreview.setImageURI(uri);

                            }

                        }

                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_journal);

        dbHelper = new DBHelper(this);

        imgPreview = findViewById(R.id.imgPreview);

        etTitle = findViewById(R.id.etTitle);
        etLocation = findViewById(R.id.etLocation);
        etDate = findViewById(R.id.etDate);
        etDescription = findViewById(R.id.etDescription);

        btnSaveJournal = findViewById(R.id.btnSaveJournal);

        cardPhoto = findViewById(R.id.cardPhoto);

        // Receive data from Trip Details (if available)
        String tripName = getIntent().getStringExtra("tripName");
        String destination = getIntent().getStringExtra("destination");

        if (tripName != null && !tripName.isEmpty()) {
            etTitle.setText(tripName);
        }

        if (destination != null && !destination.isEmpty()) {
            etLocation.setText(destination);
        }

        cardPhoto.setOnClickListener(v -> openGallery());

        etDate.setOnClickListener(v -> showDatePicker());

        btnSaveJournal.setOnClickListener(v -> saveJournal());

    }

    private void openGallery() {

        Intent intent = new Intent(Intent.ACTION_PICK);

        intent.setType("image/*");

        imagePickerLauncher.launch(intent);

    }

    private void showDatePicker() {

        Calendar calendar = Calendar.getInstance();

        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {

                    String date = dayOfMonth + "/" + (month + 1) + "/" + year;

                    etDate.setText(date);

                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        dialog.show();

    }

    private void saveJournal() {

        String title = etTitle.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (title.isEmpty()
                || location.isEmpty()
                || date.isEmpty()
                || description.isEmpty()) {

            Toast.makeText(this,
                    "Please fill all fields",
                    Toast.LENGTH_SHORT).show();

            return;

        }

        boolean success = dbHelper.insertJournal(
                title,
                location,
                date,
                description,
                imageUri
        );

        if (success) {

            Toast.makeText(this,
                    "Memory Saved!",
                    Toast.LENGTH_SHORT).show();

            finish();

        } else {

            Toast.makeText(this,
                    "Failed to Save",
                    Toast.LENGTH_SHORT).show();

        }

    }

}
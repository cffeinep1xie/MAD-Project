package com.example.smarttravelapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

import java.util.Calendar;

public class CreateTripActivity extends AppCompatActivity {

    EditText etTripName, etDestination, etBudget, etNotes;

    TextView txtStartDate, txtEndDate;

    MaterialCardView cardStartDate, cardEndDate;

    Button btnSaveTrip;

    DBHelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_trip);

        dbHelper = new DBHelper(this);

        etTripName = findViewById(R.id.etTripName);
        etDestination = findViewById(R.id.etDestination);
        etBudget = findViewById(R.id.etBudget);
        etNotes = findViewById(R.id.etNotes);

        txtStartDate = findViewById(R.id.txtStartDate);
        txtEndDate = findViewById(R.id.txtEndDate);

        cardStartDate = findViewById(R.id.cardStartDate);
        cardEndDate = findViewById(R.id.cardEndDate);

        btnSaveTrip = findViewById(R.id.btnSaveTrip);

        // Date Picker
        cardStartDate.setOnClickListener(v -> showDatePicker(txtStartDate));
        cardEndDate.setOnClickListener(v -> showDatePicker(txtEndDate));

        // Save Trip
        btnSaveTrip.setOnClickListener(v -> {

            String tripName = etTripName.getText().toString().trim();
            String destination = etDestination.getText().toString().trim();

            // Corrected
            String startDate = txtStartDate.getText().toString().trim();
            String endDate = txtEndDate.getText().toString().trim();

            String budget = etBudget.getText().toString().trim();
            String notes = etNotes.getText().toString().trim();

            if (tripName.isEmpty()
                    || destination.isEmpty()
                    || budget.isEmpty()) {

                Toast.makeText(
                        CreateTripActivity.this,
                        "Please fill all required fields",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean inserted = dbHelper.insertTrip(
                    tripName,
                    destination,
                    startDate,
                    endDate,
                    budget,
                    notes
            );

            if (inserted) {

                Toast.makeText(
                        CreateTripActivity.this,
                        "Trip Created Successfully!",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent = new Intent(
                        CreateTripActivity.this,
                        MyTripsActivity.class
                );

                startActivity(intent);
                finish();

            } else {

                Toast.makeText(
                        CreateTripActivity.this,
                        "Failed to save trip",
                        Toast.LENGTH_SHORT
                ).show();
            }

        });

    }

    private void showDatePicker(TextView textView) {

        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {

                    String date = selectedDay + "/"
                            + (selectedMonth + 1) + "/"
                            + selectedYear;

                    textView.setText(date);

                },
                year,
                month,
                day
        );

        dialog.show();
    }
}
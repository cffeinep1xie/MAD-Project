package com.example.smarttravelapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.smarttravelapp.model.Profile;

public class ProfileDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Profile.db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_PROFILE = "profile";

    private static final String COL_ID = "id";
    private static final String COL_NAME = "name";
    private static final String COL_EMAIL = "email";
    private static final String COL_PHONE = "phone";
    private static final String COL_CITY = "city";
    private static final String COL_BIO = "bio";

    public ProfileDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + TABLE_PROFILE + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_NAME + " TEXT,"
                + COL_EMAIL + " TEXT UNIQUE,"
                + COL_PHONE + " TEXT,"
                + COL_CITY + " TEXT,"
                + COL_BIO + " TEXT)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFILE);
        onCreate(db);

    }

    // Save Profile
    public boolean saveProfile(Profile profile, String email) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, profile.getName());
        values.put(COL_EMAIL, email);
        values.put(COL_PHONE, profile.getPhone());
        values.put(COL_CITY, profile.getCity());
        values.put(COL_BIO, profile.getBio());

        long result = db.insert(TABLE_PROFILE, null, values);

        return result != -1;
    }

    // Get Profile
    public Cursor getProfile(String email) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_PROFILE + " WHERE email = ?",
                new String[]{email});
    }

    // Check if profile exists
    public boolean profileExists(String email)  {

        Cursor cursor = getProfile(email);

        boolean exists = cursor.moveToFirst();

        cursor.close();

        return exists;
    }

    // Update Profile
        public void updateProfile(Profile profile, String email) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

            values.put(COL_NAME, profile.getName());
            values.put(COL_EMAIL, email);
            values.put(COL_PHONE, profile.getPhone());
            values.put(COL_CITY, profile.getCity());
            values.put(COL_BIO, profile.getBio());

            db.update(TABLE_PROFILE,
                    values,
                    COL_EMAIL + "=?",
                    new String[]{email});
    }

    public void deleteProfile() {

        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("profile", null, null);

    }
}
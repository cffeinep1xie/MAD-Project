package com.example.smarttravelapp.model;

public class Trip {

    private String tripName;
    private String destination;
    private String startDate;
    private String endDate;
    private String budget;
    private String notes;

    public Trip(String tripName,
                String destination,
                String startDate,
                String endDate,
                String budget,
                String notes) {

        this.tripName = tripName;
        this.destination = destination;
        this.startDate = startDate;
        this.endDate = endDate;
        this.budget = budget;
        this.notes = notes;
    }

    public String getTripName() {
        return tripName;
    }

    public String getDestination() {
        return destination;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getBudget() {
        return budget;
    }

    public String getNotes() {
        return notes;
    }
}
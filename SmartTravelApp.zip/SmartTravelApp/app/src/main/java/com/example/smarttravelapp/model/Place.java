package com.example.smarttravelapp.model;

public class Place {

    private int image;
    private String name;
    private String location;
    private float rating;
    private String description;

    public Place(int image,
                 String name,
                 String location,
                 float rating,
                 String description) {

        this.image = image;
        this.name = name;
        this.location = location;
        this.rating = rating;
    }

    public int getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public float getRating() {
        return rating;
    }

    public String getDescription() {
        return description;
    }
}
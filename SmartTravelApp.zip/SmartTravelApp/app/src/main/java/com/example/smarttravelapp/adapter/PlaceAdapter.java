package com.example.smarttravelapp.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import java.util.List;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.PlaceReviewActivity;
import com.example.smarttravelapp.R;
import com.example.smarttravelapp.model.Place;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class PlaceAdapter extends RecyclerView.Adapter<PlaceAdapter.ViewHolder>
        implements Filterable {

    private final ArrayList<Place> placeList;
    private final ArrayList<Place> placeListFull;

    public PlaceAdapter(ArrayList<Place> placeList) {

        this.placeList = placeList;
        this.placeListFull = new ArrayList<>(placeList);

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgPlace;
        TextView tvPlaceName, tvLocation, tvRating, tvDescription;
        MaterialButton btnReviews;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgPlace = itemView.findViewById(R.id.imgPlace);
            tvPlaceName = itemView.findViewById(R.id.tvPlaceName);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvRating = itemView.findViewById(R.id.tvRating);
            tvDescription = itemView.findViewById(R.id.tvDescription);

            btnReviews = itemView.findViewById(R.id.btnReviews);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.place_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Place place = placeList.get(position);

        holder.imgPlace.setImageResource(place.getImage());

        holder.tvPlaceName.setText(place.getName());

        holder.tvLocation.setText(place.getLocation());

        holder.tvRating.setText(String.valueOf(place.getRating()));

        holder.tvDescription.setText(place.getDescription());

        holder.btnReviews.setOnClickListener(v -> {

            Intent intent = new Intent(v.getContext(), PlaceReviewActivity.class);

            intent.putExtra("place", place.getName());

            v.getContext().startActivity(intent);

        });

    }

    @Override
    public int getItemCount() {
        return placeList.size();
    }

    @Override
    public Filter getFilter() {
        return placeFilter;
    }

    private final Filter placeFilter = new Filter() {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            List<Place> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {

                filteredList.addAll(placeListFull);

            } else {

                String filterPattern = constraint.toString().toLowerCase().trim();

                for (Place place : placeListFull) {

                    if (place.getName().toLowerCase().contains(filterPattern)
                            || place.getLocation().toLowerCase().contains(filterPattern)) {

                        filteredList.add(place);

                    }

                }

            }

            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            placeList.clear();

            placeList.addAll((List) results.values);

            notifyDataSetChanged();

        }
    };

}
package com.example.smarttravelapp.model;

public class Profile {

    private String name;
    private String email;
    private String phone;
    private String city;
    private String bio;

    public Profile(String name, String email, String phone, String city, String bio) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.city = city;
        this.bio = bio;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getCity() {
        return city;
    }

    public String getBio() {
        return bio;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }
}
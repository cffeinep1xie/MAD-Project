package com.example.smarttravelapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.R;
import com.example.smarttravelapp.model.Destination;

import java.util.ArrayList;

public class DestinationAdapter extends RecyclerView.Adapter<DestinationAdapter.ViewHolder> {

    private ArrayList<Destination> destinationList;

    public DestinationAdapter(ArrayList<Destination> destinationList) {
        this.destinationList = destinationList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_destination, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Destination destination = destinationList.get(position);

        holder.imgDestination.setImageResource(destination.getImage());
        holder.txtDestination.setText(destination.getName());
        holder.txtDescription.setText(destination.getDescription());

    }

    @Override
    public int getItemCount() {
        return destinationList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgDestination;
        TextView txtDestination, txtDescription;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgDestination = itemView.findViewById(R.id.imgDestination);
            txtDestination = itemView.findViewById(R.id.txtDestination);
            txtDescription = itemView.findViewById(R.id.txtDescription);
        }
    }
}

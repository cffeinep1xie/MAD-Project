package com.example.smarttravelapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "TravelDB";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_TRIPS = "Trips";

    public static final String COL_ID = "id";
    public static final String COL_NAME = "tripName";
    public static final String COL_DESTINATION = "destination";
    public static final String COL_START = "startDate";
    public static final String COL_END = "endDate";
    public static final String COL_BUDGET = "budget";
    public static final String COL_NOTES = "notes";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_TRIPS + "(" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_NAME + " TEXT," +
                COL_DESTINATION + " TEXT," +
                COL_START + " TEXT," +
                COL_END + " TEXT," +
                COL_BUDGET + " TEXT," +
                COL_NOTES + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIPS);
        onCreate(db);

    }

    // Insert Trip

    public boolean insertTrip(String name,
                              String destination,
                              String start,
                              String end,
                              String budget,
                              String notes){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NAME,name);
        values.put(COL_DESTINATION,destination);
        values.put(COL_START,start);
        values.put(COL_END,end);
        values.put(COL_BUDGET,budget);
        values.put(COL_NOTES,notes);

        long result = db.insert(TABLE_TRIPS,null,values);

        return result!=-1;

    }

    // Read All Trips

    public Cursor getAllTrips(){

        SQLiteDatabase db=this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM "+TABLE_TRIPS,null);

    }

}
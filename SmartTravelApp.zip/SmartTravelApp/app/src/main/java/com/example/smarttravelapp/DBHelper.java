package com.example.smarttravelapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    //Trip details table
    private static final String DATABASE_NAME = "TravelDB";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_TRIPS = "Trips";

    public static final String COL_ID = "id";
    public static final String COL_NAME = "tripName";
    public static final String COL_DESTINATION = "destination";
    public static final String COL_START = "startDate";
    public static final String COL_END = "endDate";
    public static final String COL_BUDGET = "budget";
    public static final String COL_NOTES = "notes";

    // Journal Table
    public static final String TABLE_JOURNAL = "Journal";

    public static final String J_ID = "id";
    public static final String J_TITLE = "title";
    public static final String J_LOCATION = "location";
    public static final String J_DATE = "date";
    public static final String J_DESCRIPTION = "description";
    public static final String J_IMAGE = "image";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_TRIPS + "(" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_NAME + " TEXT," +
                COL_DESTINATION + " TEXT," +
                COL_START + " TEXT," +
                COL_END + " TEXT," +
                COL_BUDGET + " TEXT," +
                COL_NOTES + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_JOURNAL + "(" +
                J_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                J_TITLE + " TEXT," +
                J_LOCATION + " TEXT," +
                J_DATE + " TEXT," +
                J_DESCRIPTION + " TEXT," +
                J_IMAGE + " TEXT)");
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIPS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_JOURNAL);

        onCreate(db);
    }

    // Insert Trip

    public boolean insertTrip(String name,
                              String destination,
                              String start,
                              String end,
                              String budget,
                              String notes){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NAME,name);
        values.put(COL_DESTINATION,destination);
        values.put(COL_START,start);
        values.put(COL_END,end);
        values.put(COL_BUDGET,budget);
        values.put(COL_NOTES,notes);

        long result = db.insert(TABLE_TRIPS,null,values);

        return result!=-1;

    }

    // Read All Trips

    public Cursor getAllTrips(){

        SQLiteDatabase db=this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM "+TABLE_TRIPS,null);

    }

    // Delete Trip
    public boolean deleteTrip(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rows = db.delete(
                TABLE_TRIPS,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );
        db.close();
        return rows > 0;
    }

    // Get Single Trip
    public Cursor getTripById(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_TRIPS,
                null,
                COL_ID + "=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );
    }

    // Update Trip
    public boolean updateTrip(int id,
                              String name,
                              String destination,
                              String start,
                              String end,
                              String budget,
                              String notes) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NAME, name);
        values.put(COL_DESTINATION, destination);
        values.put(COL_START, start);
        values.put(COL_END, end);
        values.put(COL_BUDGET, budget);
        values.put(COL_NOTES, notes);

        int rows = db.update(
                TABLE_TRIPS,
                values,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        long result = db.insert(TABLE_TRIPS, null, values);
        db.close();
        return rows > 0;
    }

    // Get Total Trips
    public int getTripCount() {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_TRIPS,
                null
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    //Insert Journal Entry
    public boolean insertJournal(String title,
                                 String location,
                                 String date,
                                 String description,
                                 String image){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(J_TITLE, title);
        values.put(J_LOCATION, location);
        values.put(J_DATE, date);
        values.put(J_DESCRIPTION, description);
        values.put(J_IMAGE, image);

        long result = db.insert(TABLE_JOURNAL, null, values);

        db.close();

        return result != -1;
    }

    //Get All Journal Entries
    public Cursor getAllJournalEntries(){

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_JOURNAL + " ORDER BY " + J_ID + " DESC",
                null
        );
    }

    //Delete Journal Entry
    public boolean deleteJournal(int id){

        SQLiteDatabase db = this.getWritableDatabase();

        int rows = db.delete(
                TABLE_JOURNAL,
                J_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        db.close();

        return rows > 0;
    }

    //Get journal count
    public int getJournalCount(){

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_JOURNAL,
                null
        );

        int count = 0;

        if(cursor.moveToFirst()){
            count = cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    //

}
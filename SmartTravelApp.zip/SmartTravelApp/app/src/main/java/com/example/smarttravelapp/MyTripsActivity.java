package com.example.smarttravelapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.adapter.TripAdapter;
import com.example.smarttravelapp.model.Trip;

import java.util.ArrayList;

public class MyTripsActivity extends AppCompatActivity {

    RecyclerView rvTrips;
    ArrayList<Trip> tripList;
    TripAdapter adapter;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_trips);

        rvTrips = findViewById(R.id.rvTrips);

        tripList = new ArrayList<>();

        dbHelper = new DBHelper(this);

        loadTrips();

        adapter = new TripAdapter(tripList);

        rvTrips.setLayoutManager(new LinearLayoutManager(this));
        rvTrips.setAdapter(adapter);
    }

    private void loadTrips() {

        Cursor cursor = dbHelper.getAllTrips();

        if (cursor.moveToFirst()) {

            do {

                tripList.add(new Trip(
                        cursor.getString(1),   // Trip Name
                        cursor.getString(2),   // Destination
                        cursor.getString(3),   // Start Date
                        cursor.getString(4),   // End Date
                        cursor.getString(5),   // Budget
                        cursor.getString(6)    // Notes
                ));

            } while (cursor.moveToNext());
        }

        cursor.close();
    }
}
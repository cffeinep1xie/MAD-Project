package com.example.smarttravelapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView txtSignUp;
    SharedPreferences preferences;
    private UserDBHelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        txtSignUp = findViewById(R.id.txtSignUp);

        dbHelper = new UserDBHelper(this);

        preferences = getSharedPreferences("UserSession", MODE_PRIVATE);

        btnLogin.setOnClickListener(v -> {

            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            // Empty fields
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this,
                        "Please enter email and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Check credentials
            if (dbHelper.checkLogin(email, password)) {

                // Save login session
                SharedPreferences preferences =
                        getSharedPreferences("UserSession", MODE_PRIVATE);

                String name = dbHelper.getName(email);

                preferences.edit()
                        .putBoolean("isLoggedIn", true)
                        .putString("loggedInEmail", email)
                        .putString("email", email)
                        .putString("name", name)
                        .apply();

                String enteredEmail = etEmail.getText().toString().trim();

                Toast.makeText(LoginActivity.this,
                        "Login Successful",
                        Toast.LENGTH_SHORT).show();

                ProfileDBHelper profileDB = new ProfileDBHelper(this);

                if (profileDB.profileExists(enteredEmail)) {

                    startActivity(new Intent(LoginActivity.this, MainActivity.class));

                } else {

                    startActivity(new Intent(LoginActivity.this, CreateProfileActivity.class));

                }

                finish();

            } else {

                Toast.makeText(LoginActivity.this,
                        "Invalid email or password",
                        Toast.LENGTH_SHORT).show();

            }

        });

        txtSignUp.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
        });
    }
}
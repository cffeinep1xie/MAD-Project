package com.example.smarttravelapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageButton;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import com.example.smarttravelapp.adapter.PlaceAdapter;
import com.example.smarttravelapp.model.Place;

import java.util.ArrayList;

public class ExploreActivity extends AppCompatActivity {

    RecyclerView rvPlaces;

    ArrayList<Place> placeList;

    PlaceAdapter adapter;
    TextInputEditText etSearch;
    MaterialButton btnAiSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        ImageButton btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        rvPlaces = findViewById(R.id.rvPlaces);
        etSearch = findViewById(R.id.etSearch);

        placeList = new ArrayList<>();

        loadPlaces();

        adapter = new PlaceAdapter(placeList);

        rvPlaces.setLayoutManager(new LinearLayoutManager(this));

        rvPlaces.setAdapter(adapter);
        btnAiSearch = findViewById(R.id.btnAiSearch);

        btnAiSearch.setOnClickListener(v -> {

            String destination = etSearch.getText().toString().trim();

            if(destination.isEmpty()){
                etSearch.setError("Enter a destination");
                return;
            }

            Intent intent = new Intent(
                    ExploreActivity.this,
                    PlaceReviewActivity.class);

            intent.putExtra("place", destination);

            startActivity(intent);

        });

        etSearch.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {}

        });

    }

    private void loadPlaces() {

        placeList.add(new Place(
                R.drawable.goa,
                "Goa",
                "Goa, India",
                4.8f,
                "Golden beaches, nightlife and Portuguese heritage."
        ));

        placeList.add(new Place(
                R.drawable.manali,
                "Manali",
                "Himachal Pradesh",
                4.7f,
                "Snow-covered mountains and adventure sports."
        ));

        placeList.add(new Place(
                R.drawable.jaipur,
                "Jaipur",
                "Rajasthan",
                4.8f,
                "The Pink City with majestic forts and palaces."
        ));

        // Remaining destinations (placeholder image)

        placeList.add(new Place(R.drawable.ic_travel,"Taj Mahal","Agra",4.9f,"One of the Seven Wonders of the World."));
        placeList.add(new Place(R.drawable.ic_travel,"Kerala","Kerala",4.8f,"God's Own Country with serene backwaters."));
        placeList.add(new Place(R.drawable.ic_travel,"Ladakh","Ladakh",4.9f,"High-altitude deserts and breathtaking landscapes."));
        placeList.add(new Place(R.drawable.ic_travel,"Udaipur","Rajasthan",4.8f,"City of Lakes."));
        placeList.add(new Place(R.drawable.ic_travel,"Ooty","Tamil Nadu",4.6f,"Beautiful hill station."));
        placeList.add(new Place(R.drawable.ic_travel,"Munnar","Kerala",4.8f,"Tea gardens and misty hills."));
        placeList.add(new Place(R.drawable.ic_travel,"Rishikesh","Uttarakhand",4.7f,"Yoga capital of the world."));
        placeList.add(new Place(R.drawable.ic_travel,"Shimla","Himachal Pradesh",4.6f,"Colonial hill station."));
        placeList.add(new Place(R.drawable.ic_travel,"Darjeeling","West Bengal",4.7f,"Tea plantations and toy train."));
        placeList.add(new Place(R.drawable.ic_travel,"Mysore","Karnataka",4.7f,"Palaces and rich heritage."));
        placeList.add(new Place(R.drawable.ic_travel,"Hampi","Karnataka",4.8f,"UNESCO World Heritage ruins."));
        placeList.add(new Place(R.drawable.ic_travel,"Andaman","Andaman",4.9f,"Crystal-clear beaches."));
        placeList.add(new Place(R.drawable.ic_travel,"Kashmir","Jammu & Kashmir",4.9f,"Paradise on Earth."));
        placeList.add(new Place(R.drawable.ic_travel,"Varanasi","Uttar Pradesh",4.8f,"One of the world's oldest living cities."));
        placeList.add(new Place(R.drawable.ic_travel,"Coorg","Karnataka",4.7f,"Coffee plantations and waterfalls."));
        placeList.add(new Place(R.drawable.ic_travel,"Mount Abu","Rajasthan",4.5f,"Rajasthan's only hill station."));
        placeList.add(new Place(R.drawable.ic_travel,"Pondicherry","Tamil Nadu",4.7f,"French architecture and beaches."));

    }

}
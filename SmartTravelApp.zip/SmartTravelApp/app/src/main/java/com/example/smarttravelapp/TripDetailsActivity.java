package com.example.smarttravelapp;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TripDetailsActivity extends AppCompatActivity {

    private TextView tvTripName;
    private TextView tvDestination;
    private TextView tvDates;
    private TextView tvBudget;
    private TextView tvNotes;

    private TextView tvRating;
    private TextView tvReview;
    private TextView tvHighlight1;
    private TextView tvHighlight2;
    private TextView tvHighlight3;
    private TextView tvHighlight4;

    private ImageButton btnBack;
    private ImageView imgDestination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_details);

        // Views
        btnBack = findViewById(R.id.btnBack);

        tvTripName = findViewById(R.id.tvTripName);
        tvDestination = findViewById(R.id.tvDestination);
        tvDates = findViewById(R.id.tvDates);
        tvBudget = findViewById(R.id.tvBudget);
        tvNotes = findViewById(R.id.tvNotes);

        tvRating = findViewById(R.id.tvRating);
        tvReview = findViewById(R.id.tvReview);

        tvHighlight1 = findViewById(R.id.tvHighlight1);
        tvHighlight2 = findViewById(R.id.tvHighlight2);
        tvHighlight3 = findViewById(R.id.tvHighlight3);
        tvHighlight4 = findViewById(R.id.tvHighlight4);

        imgDestination = findViewById(R.id.imgDestination);

        // Get Trip Data
        String tripName = getIntent().getStringExtra("tripName");
        String destination = getIntent().getStringExtra("destination");
        String startDate = getIntent().getStringExtra("startDate");
        String endDate = getIntent().getStringExtra("endDate");
        String budget = getIntent().getStringExtra("budget");
        String notes = getIntent().getStringExtra("notes");

        // Set Trip Info
        tvTripName.setText(tripName);
        tvDestination.setText(destination);
        tvDates.setText(startDate + " - " + endDate);
        tvBudget.setText("₹ " + budget);

        if (notes != null && !notes.trim().isEmpty()) {
            tvNotes.setText(notes);
        } else {
            tvNotes.setText("No notes available.");
        }

        setDestinationImage(destination);

        // Loading Text
        tvRating.setText("Loading...");
        tvReview.setText("🤖 AI is generating a travel review...");

        // Clear highlights while loading
        tvHighlight1.setText("");
        tvHighlight2.setText("");
        tvHighlight3.setText("");
        tvHighlight4.setText("");

        // Gemini AI
        GeminiHelper.generateReview(destination, new GeminiHelper.GeminiCallback() {

            @Override
            public void onSuccess(String response) {

                runOnUiThread(() -> parseGeminiResponse(response));

            }

            @Override
            public void onFailure(String error) {

                runOnUiThread(() -> {

                    tvRating.setText("Unavailable");
                    tvReview.setText("Couldn't generate AI review.");

                });

            }
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void parseGeminiResponse(String text) {

        String[] lines = text.split("\n");

        String rating = "";
        String summary = "";
        String h1 = "";
        String h2 = "";
        String h3 = "";
        String h4 = "";

        for (String line : lines) {

            line = line.trim();

            if (line.startsWith("Rating:")) {

                rating = line.replace("Rating:", "").trim();

            } else if (line.startsWith("Summary:")) {

                summary = line.replace("Summary:", "").trim();

            } else if (line.startsWith("Highlight1:")) {

                h1 = "✔ " + line.replace("Highlight1:", "").trim();

            } else if (line.startsWith("Highlight2:")) {

                h2 = "✔ " + line.replace("Highlight2:", "").trim();

            } else if (line.startsWith("Highlight3:")) {

                h3 = "✔ " + line.replace("Highlight3:", "").trim();

            } else if (line.startsWith("Highlight4:")) {

                h4 = "✔ " + line.replace("Highlight4:", "").trim();

            }

        }

        tvRating.setText("⭐ " + rating);
        tvReview.setText(summary);

        tvHighlight1.setText(h1);
        tvHighlight2.setText(h2);
        tvHighlight3.setText(h3);
        tvHighlight4.setText(h4);

    }

    private void setDestinationImage(String destination) {

        if (destination == null) {

            imgDestination.setImageResource(R.drawable.default_trip);
            return;

        }

        switch (destination.toLowerCase()) {

            case "goa":
                imgDestination.setImageResource(R.drawable.goa);
                break;

            case "manali":
                imgDestination.setImageResource(R.drawable.manali);
                break;

            case "jaipur":
                imgDestination.setImageResource(R.drawable.jaipur);
                break;

            default:
                imgDestination.setImageResource(R.drawable.default_trip);
                break;

        }

    }
}
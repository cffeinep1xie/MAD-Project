package com.example.smarttravelapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlaceReviewActivity extends AppCompatActivity {

    TextView tvPlaceName, tvSummary;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_review);

        tvPlaceName = findViewById(R.id.tvPlaceName);
        tvSummary = findViewById(R.id.tvSummary);
        progressBar = findViewById(R.id.progressBar);

        String place = getIntent().getStringExtra("place");

        tvPlaceName.setText(place);

        loadSummary(place);
    }

    private void loadSummary(String place) {

        progressBar.setVisibility(View.VISIBLE);
        tvSummary.setText("Generating AI review...");

        GeminiHelper.generateReview(place, new GeminiHelper.GeminiCallback() {

            @Override
            public void onSuccess(String response) {

                runOnUiThread(() -> {

                    progressBar.setVisibility(View.GONE);

                    tvSummary.setText(formatResponse(response));

                });

            }

            @Override
            public void onFailure(String error) {

                runOnUiThread(() -> {

                    progressBar.setVisibility(View.GONE);

                    tvSummary.setText("Couldn't generate AI review.");

                });

            }

        });

    }

    private String formatResponse(String text) {

        String[] lines = text.split("\n");

        String rating = "";
        String summary = "";
        String h1 = "";
        String h2 = "";
        String h3 = "";
        String h4 = "";

        for (String line : lines) {

            line = line.trim();

            if (line.startsWith("Rating:")) {

                rating = line.replace("Rating:", "").trim();

            } else if (line.startsWith("Summary:")) {

                summary = line.replace("Summary:", "").trim();

            } else if (line.startsWith("Highlight1:")) {

                h1 = "✔ " + line.replace("Highlight1:", "").trim();

            } else if (line.startsWith("Highlight2:")) {

                h2 = "✔ " + line.replace("Highlight2:", "").trim();

            } else if (line.startsWith("Highlight3:")) {

                h3 = "✔ " + line.replace("Highlight3:", "").trim();

            } else if (line.startsWith("Highlight4:")) {

                h4 = "✔ " + line.replace("Highlight4:", "").trim();

            }

        }

        return "⭐ " + rating +

                "\n\n" +

                summary +

                "\n\n" +

                h1 +

                "\n" +

                h2 +

                "\n" +

                h3 +

                "\n" +

                h4;

    }

}
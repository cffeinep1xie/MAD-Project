package com.example.smarttravelapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlaceReviewActivity extends AppCompatActivity {

    TextView tvPlaceName, tvSummary;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_review);

        tvPlaceName = findViewById(R.id.tvPlaceName);
        tvSummary = findViewById(R.id.tvSummary);
        progressBar = findViewById(R.id.progressBar);

        String place = getIntent().getStringExtra("place");

        tvPlaceName.setText(place);

        loadSummary(place);
    }

    private void loadSummary(String place) {

        progressBar.setVisibility(View.GONE);

        switch (place) {

            case "Goa":

                tvSummary.setText(
                        "⭐ 4.8/5\n\n" +
                                "Visitors love Goa for its beautiful beaches, lively nightlife, delicious seafood and water sports. Most travellers recommend visiting between November and February for pleasant weather."
                );

                break;

            case "Manali":

                tvSummary.setText(
                        "⭐ 4.7/5\n\n" +
                                "Travellers enjoy snow-covered mountains, adventure sports, scenic valleys and peaceful cafes. Best visited during winter for snowfall."
                );

                break;

            case "Jaipur":

                tvSummary.setText(
                        "⭐ 4.8/5\n\n" +
                                "Known for magnificent forts, palaces, local markets and authentic Rajasthani food. Visitors recommend Amber Fort and Hawa Mahal."
                );

                break;

            default:

                tvSummary.setText(
                        "AI Review Summary will appear here.\n\nOnce the Gemini API key is configured, this page will display an AI-generated summary based on visitor reviews."
                );

        }

    }

}
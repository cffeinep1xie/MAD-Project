package com.example.smarttravelapp;

import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import com.example.smarttravelapp.adapter.DestinationAdapter;
import com.example.smarttravelapp.adapter.QuickActionAdapter;
import com.example.smarttravelapp.model.Destination;
import com.example.smarttravelapp.model.QuickAction;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvQuickActions, rvDestinations;

    private ArrayList<QuickAction> actionList;
    private ArrayList<Destination> destinationList;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageButton btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvQuickActions = findViewById(R.id.rvQuickActions);
        rvDestinations = findViewById(R.id.rvDestinations);
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        btnMenu = findViewById(R.id.btnMenu);

        setupQuickActions();
        setupDestinations();

        btnMenu.setOnClickListener(v -> {
            drawerLayout.openDrawer(GravityCompat.START);
        });

        ImageButton btnInfo = findViewById(R.id.btnNotification);

        btnInfo.setOnClickListener(v -> {

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("About Outbound")
                    .setMessage(
                            "Outbound\n\n" +
                                    "Version 1.0\n\n" +
                                    "Travel planning app with Trips, Explore, Journal and Budget features.\n\n" +
                                    "Developed by Pari Walia")
                    .setPositiveButton("OK", null)
                    .show();
        });

        navigationView.setNavigationItemSelectedListener(item -> {

            int id = item.getItemId();

            if (id == R.id.home) {

                drawerLayout.closeDrawer(GravityCompat.START);

            } else if (id == R.id.trips) {

                startActivity(new Intent(MainActivity.this, MyTripsActivity.class));

            } else if (id == R.id.journal) {

                startActivity(new Intent(MainActivity.this, JournalActivity.class));

            } else if (id == R.id.settings) {

                // We'll replace this with ProfileActivity once we create it.
                // For now you can leave it empty or show a Toast.

            }

            drawerLayout.closeDrawer(GravityCompat.START);

            return true;
        });
    }

    private void setupQuickActions() {

        actionList = new ArrayList<>();

        actionList.add(new QuickAction(R.drawable.ic_add_trip, "Create Trip"));
        actionList.add(new QuickAction(R.drawable.ic_travel, "My Trips"));
        actionList.add(new QuickAction(R.drawable.ic_journal, "Journal"));
        actionList.add(new QuickAction(R.drawable.ic_location, "Explore"));

        QuickActionAdapter adapter = new QuickActionAdapter(actionList);

        rvQuickActions.setLayoutManager(new GridLayoutManager(this, 2));
        rvQuickActions.setAdapter(adapter);
    }

    private void setupDestinations() {

        destinationList = new ArrayList<>();

        destinationList.add(new Destination(
                R.drawable.goa,
                "Goa",
                "Sunny Beaches"));

        destinationList.add(new Destination(
                R.drawable.manali,
                "Manali",
                "Snowy Mountains"));

        destinationList.add(new Destination(
                R.drawable.jaipur,
                "Jaipur",
                "Pink City"));

        DestinationAdapter adapter = new DestinationAdapter(destinationList);

        rvDestinations.setLayoutManager(
                new LinearLayoutManager(
                        this,
                        LinearLayoutManager.HORIZONTAL,
                        false));

        rvDestinations.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
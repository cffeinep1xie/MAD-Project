package com.example.smarttravelapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.adapter.DestinationAdapter;
import com.example.smarttravelapp.adapter.QuickActionAdapter;
import com.example.smarttravelapp.model.Destination;
import com.example.smarttravelapp.model.QuickAction;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvQuickActions, rvDestinations;

    private ArrayList<QuickAction> actionList;
    private ArrayList<Destination> destinationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvQuickActions = findViewById(R.id.rvQuickActions);
        rvDestinations = findViewById(R.id.rvDestinations);

        setupQuickActions();
        setupDestinations();
    }

    private void setupQuickActions() {

        actionList = new ArrayList<>();

        actionList.add(new QuickAction(R.drawable.ic_add_trip, "Create Trip"));
        actionList.add(new QuickAction(R.drawable.ic_wallet, "Budget"));
        actionList.add(new QuickAction(R.drawable.ic_journal, "Journal"));
        actionList.add(new QuickAction(R.drawable.ic_travel, "Explore"));

        QuickActionAdapter adapter = new QuickActionAdapter(actionList);

        rvQuickActions.setLayoutManager(new GridLayoutManager(this, 2));
        rvQuickActions.setAdapter(adapter);
    }

    private void setupDestinations() {

        destinationList = new ArrayList<>();

        destinationList.add(new Destination(
                R.drawable.goa,
                "Goa",
                "Sunny Beaches"));

        destinationList.add(new Destination(
                R.drawable.manali,
                "Manali",
                "Snowy Mountains"));

        destinationList.add(new Destination(
                R.drawable.jaipur,
                "Jaipur",
                "Pink City"));

        DestinationAdapter adapter = new DestinationAdapter(destinationList);

        rvDestinations.setLayoutManager(
                new LinearLayoutManager(
                        this,
                        LinearLayoutManager.HORIZONTAL,
                        false));

        rvDestinations.setAdapter(adapter);
    }
}
package com.example.smarttravelapp;

import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.widget.TextView;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import com.example.smarttravelapp.adapter.DestinationAdapter;
import com.example.smarttravelapp.adapter.QuickActionAdapter;
import com.example.smarttravelapp.model.Destination;
import com.example.smarttravelapp.model.QuickAction;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvQuickActions, rvDestinations;

    private ArrayList<QuickAction> actionList;
    private ArrayList<Destination> destinationList;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageButton btnMenu;
    private ProfileDBHelper profileDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvQuickActions = findViewById(R.id.rvQuickActions);
        rvDestinations = findViewById(R.id.rvDestinations);
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        btnMenu = findViewById(R.id.btnMenu);

        TextView txtUserName = findViewById(R.id.txtUserName);

        profileDBHelper = new ProfileDBHelper(this);

        SharedPreferences preferences =
                getSharedPreferences("UserSession", MODE_PRIVATE);

        String loggedInEmail =
                preferences.getString("loggedInEmail", "");

        Cursor cursor = profileDBHelper.getProfile(loggedInEmail);

        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(1);   // Name column
            txtUserName.setText(name + " 👋");
            cursor.close();
        }

        setupQuickActions();
        setupDestinations();

        btnMenu.setOnClickListener(v -> {
            drawerLayout.openDrawer(GravityCompat.START);
        });

        ImageButton btnInfo = findViewById(R.id.btnNotification);

        btnInfo.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });

        navigationView.setNavigationItemSelectedListener(item -> {

            int id = item.getItemId();

            if (id == R.id.home) {

                drawerLayout.closeDrawer(GravityCompat.START);

            } else if (id == R.id.profile) {

                startActivity(new Intent(MainActivity.this,
                        ProfileActivity.class));

            }else if (id == R.id.trips) {

                startActivity(new Intent(MainActivity.this, MyTripsActivity.class));

            } else if (id == R.id.journal) {

                startActivity(new Intent(MainActivity.this, JournalActivity.class));

            } else if (id == R.id.settings) {

                startActivity(new Intent(MainActivity.this,
                        SettingsActivity.class));

            } else if (id == R.id.logout) {

                new AlertDialog.Builder(this)
                        .setTitle("Logout")
                        .setMessage("Are you sure you want to logout?")
                        .setPositiveButton("Logout", (dialog, which) -> {

                            preferences.edit().clear().apply();

                            Intent intent = new Intent(MainActivity.this,
                                    LoginActivity.class);

                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK);

                            startActivity(intent);
                            finish();

                        })
                        .setNegativeButton("Cancel", null)
                        .show();

            }

            drawerLayout.closeDrawer(GravityCompat.START);

            return true;
        });
    }

    private void setupQuickActions() {

        actionList = new ArrayList<>();

        actionList.add(new QuickAction(R.drawable.ic_add_trip, "Create Trip"));
        actionList.add(new QuickAction(R.drawable.ic_travel, "My Trips"));
        actionList.add(new QuickAction(R.drawable.ic_journal, "Journal"));
        actionList.add(new QuickAction(R.drawable.ic_location, "Explore"));

        QuickActionAdapter adapter = new QuickActionAdapter(actionList);

        rvQuickActions.setLayoutManager(new GridLayoutManager(this, 2));
        rvQuickActions.setAdapter(adapter);
    }

    private void setupDestinations() {

        destinationList = new ArrayList<>();

        destinationList.add(new Destination(
                R.drawable.goa,
                "Goa",
                "Sunny Beaches"));

        destinationList.add(new Destination(
                R.drawable.manali,
                "Manali",
                "Snowy Mountains"));

        destinationList.add(new Destination(
                R.drawable.jaipur,
                "Jaipur",
                "Pink City"));

        DestinationAdapter adapter = new DestinationAdapter(destinationList);

        rvDestinations.setLayoutManager(
                new LinearLayoutManager(
                        this,
                        LinearLayoutManager.HORIZONTAL,
                        false));

        rvDestinations.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
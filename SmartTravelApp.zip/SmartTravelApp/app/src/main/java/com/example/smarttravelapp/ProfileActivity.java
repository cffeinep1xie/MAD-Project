package com.example.smarttravelapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

import com.google.android.material.button.MaterialButton;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvPhone, tvCity, tvBio;
    private TextView tvTrips, tvJournal, tvPlaces;

    private MaterialButton btnEdit, btnLogout;
    private ImageButton btnBack;
    private TextView tvAchievements;
    private DBHelper dbHelper;
    private ProfileDBHelper profileDBHelper;
    private TextView tvLevel, tvQuote;
    private String loggedInEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileDBHelper = new ProfileDBHelper(this);
        SharedPreferences preferences =
                getSharedPreferences("UserSession", MODE_PRIVATE);

        tvAchievements = findViewById(R.id.tvAchievements);

        loggedInEmail = preferences.getString("loggedInEmail", "");
        dbHelper = new DBHelper(this);

        if (!profileDBHelper.profileExists(loggedInEmail)) {

            Intent intent = new Intent(ProfileActivity.this,
                    CreateProfileActivity.class);

            startActivity(intent);
            finish();
            return;
        }

        // Views
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvPhone = findViewById(R.id.tvPhone);
        tvCity = findViewById(R.id.tvCity);
        tvBio = findViewById(R.id.tvBio);

        tvLevel = findViewById(R.id.tvLevel);
        tvQuote = findViewById(R.id.tvQuote);

        tvTrips = findViewById(R.id.tvTrips);
        tvJournal = findViewById(R.id.tvJournal);
        tvPlaces = findViewById(R.id.tvPlaces);

        btnEdit = findViewById(R.id.btnEdit);
        btnLogout = findViewById(R.id.btnLogout);
        btnBack = findViewById(R.id.btnBack);

        loadProfile();
        loadStats();

        btnBack.setOnClickListener(v -> finish());

        btnLogout.setOnClickListener(v -> {

            preferences.edit().clear().apply();

            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        });

        btnEdit.setOnClickListener(v -> {

            Intent intent = new Intent(ProfileActivity.this,
                    CreateProfileActivity.class);

            startActivity(intent);

        });

    }

    private void loadProfile() {

        Cursor cursor = profileDBHelper.getProfile(loggedInEmail);

        if (cursor != null && cursor.moveToFirst())  {

            tvName.setText(cursor.getString(1));
            tvEmail.setText(cursor.getString(2));
            tvPhone.setText("📞 " + cursor.getString(3));
            tvCity.setText("🏠 " + cursor.getString(4));
            tvBio.setText("✈️ " + cursor.getString(5));

        } else {

            startActivity(new Intent(ProfileActivity.this,
                    CreateProfileActivity.class));
            finish();
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProfile();
        loadStats();
    }

    private void loadStats() {

        int trips = dbHelper.getTripCount();
        int journals = dbHelper.getJournalCount();

        StringBuilder achievements = new StringBuilder();

        if (trips == 0 && journals == 0) {

            achievements.append("🏆 Start recording your journeys to unlock achievements!");

        } else {

            if (trips >= 1)
                achievements.append("🌱 First Journey\n");

            if (journals >= 1)
                achievements.append("📖 Travel Writer\n");

            if (trips >= 5)
                achievements.append("🎒 Explorer\n");

            if (trips >= 10)
                achievements.append("🌍 World Wanderer\n");
        }

        tvAchievements.setText(achievements.toString());


    }
}
package com.example.smarttravelapp.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.R;
import com.example.smarttravelapp.TripDetailsActivity;
import com.example.smarttravelapp.model.Trip;

import java.util.ArrayList;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.ViewHolder> {

    private final ArrayList<Trip> tripList;

    public TripAdapter(ArrayList<Trip> tripList) {
        this.tripList = tripList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvTripName, tvDestination, tvDates, tvBudget;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTripName = itemView.findViewById(R.id.tvTripName);
            tvDestination = itemView.findViewById(R.id.tvDestination);
            tvDates = itemView.findViewById(R.id.tvDates);
            tvBudget = itemView.findViewById(R.id.tvBudget);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.trip_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Trip trip = tripList.get(position);

        holder.tvTripName.setText(trip.getTripName());
        holder.tvDestination.setText(trip.getDestination());
        holder.tvDates.setText(trip.getStartDate() + " - " + trip.getEndDate());
        holder.tvBudget.setText("₹ " + trip.getBudget());

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(v.getContext(), TripDetailsActivity.class);

            intent.putExtra("tripName", trip.getTripName());
            intent.putExtra("destination", trip.getDestination());
            intent.putExtra("startDate", trip.getStartDate());
            intent.putExtra("endDate", trip.getEndDate());
            intent.putExtra("budget", trip.getBudget());
            intent.putExtra("notes", trip.getNotes());

            v.getContext().startActivity(intent);

        });

    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }
}
package com.example.smarttravelapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.app.AlertDialog;
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.DBHelper;
import com.example.smarttravelapp.R;
import com.example.smarttravelapp.TripDetailsActivity;
import com.example.smarttravelapp.model.Trip;

import java.util.ArrayList;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.ViewHolder> {

    private final ArrayList<Trip> tripList;
    private final Context context;
    private final DBHelper dbHelper;

    public TripAdapter(Context context,
                       ArrayList<Trip> tripList,
                       DBHelper dbHelper) {

        this.context = context;
        this.tripList = tripList;
        this.dbHelper = dbHelper;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvTripName, tvDestination, tvDates, tvBudget;
        ImageButton btnView, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTripName = itemView.findViewById(R.id.tvTripName);
            tvDestination = itemView.findViewById(R.id.tvDestination);
            tvDates = itemView.findViewById(R.id.tvDates);
            tvBudget = itemView.findViewById(R.id.tvBudget);
            btnView = itemView.findViewById(R.id.btnView);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.trip_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Trip trip = tripList.get(position);

        holder.tvTripName.setText(trip.getTripName());
        holder.tvDestination.setText(trip.getDestination());
        holder.tvDates.setText(trip.getStartDate() + " - " + trip.getEndDate());
        holder.tvBudget.setText("₹ " + trip.getBudget());

        holder.btnView.setOnClickListener(v -> {

            Intent intent = new Intent(context, TripDetailsActivity.class);

            intent.putExtra("tripName", trip.getTripName());
            intent.putExtra("destination", trip.getDestination());
            intent.putExtra("startDate", trip.getStartDate());
            intent.putExtra("endDate", trip.getEndDate());
            intent.putExtra("budget", trip.getBudget());
            intent.putExtra("notes", trip.getNotes());

            context.startActivity(intent);

        });

        holder.btnDelete.setOnClickListener(v -> {

            new AlertDialog.Builder(context)
                    .setTitle("Delete Trip")
                    .setMessage("Are you sure you want to delete this trip?")
                    .setPositiveButton("Delete", (dialog, which) -> {

                        boolean deleted = dbHelper.deleteTrip(trip.getId());

                        if (deleted) {

                            tripList.remove(position);

                            notifyItemRemoved(position);

                            notifyItemRangeChanged(position, tripList.size());

                            Toast.makeText(context,
                                    "Trip Deleted",
                                    Toast.LENGTH_SHORT).show();

                        } else {

                            Toast.makeText(context,
                                    "Delete Failed",
                                    Toast.LENGTH_SHORT).show();
                        }

                    })

                    .setNegativeButton("Cancel", null)

                    .show();

        });

    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }
}
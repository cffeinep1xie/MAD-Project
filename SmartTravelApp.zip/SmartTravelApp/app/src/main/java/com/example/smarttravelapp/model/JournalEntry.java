package com.example.smarttravelapp.model;

public class JournalEntry {

    private int id;
    private String title;
    private String location;
    private String date;
    private String description;
    private String image;

    public JournalEntry(int id,
                        String title,
                        String location,
                        String date,
                        String description,
                        String image) {

        this.id = id;
        this.title = title;
        this.location = location;
        this.date = date;
        this.description = description;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getLocation() {
        return location;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public String getImage() {
        return image;
    }
}
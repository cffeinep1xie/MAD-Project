package com.example.smarttravelapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.R;
import com.example.smarttravelapp.model.QuickAction;

import java.util.ArrayList;

public class QuickActionAdapter extends RecyclerView.Adapter<QuickActionAdapter.ViewHolder> {

    private final ArrayList<QuickAction> actionList;

    public QuickActionAdapter(ArrayList<QuickAction> actionList) {
        this.actionList = actionList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_quick_action, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        QuickAction action = actionList.get(position);

        holder.icon.setImageResource(action.getIcon());
        holder.title.setText(action.getTitle());

    }

    @Override
    public int getItemCount() {
        return actionList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView icon;
        TextView title;

        ViewHolder(View itemView) {
            super(itemView);

            icon = itemView.findViewById(R.id.imgAction);
            title = itemView.findViewById(R.id.txtAction);
        }
    }
}

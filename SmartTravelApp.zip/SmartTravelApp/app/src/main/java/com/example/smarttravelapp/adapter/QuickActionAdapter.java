package com.example.smarttravelapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.MyTripsActivity;
import com.example.smarttravelapp.JournalActivity;
import com.example.smarttravelapp.ExploreActivity;
import com.example.smarttravelapp.R;
import com.example.smarttravelapp.model.QuickAction;

import java.util.ArrayList;
import android.content.Intent;
import com.example.smarttravelapp.CreateTripActivity;

public class QuickActionAdapter extends RecyclerView.Adapter<QuickActionAdapter.ViewHolder> {

    private final ArrayList<QuickAction> actionList;

    public QuickActionAdapter(ArrayList<QuickAction> actionList) {
        this.actionList = actionList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_quick_action, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        QuickAction action = actionList.get(position);

        holder.icon.setImageResource(action.getIcon());
        holder.title.setText(action.getTitle());

        holder.itemView.setOnClickListener(v -> {

            Intent intent = null;

            switch (action.getTitle()) {

                case "Create Trip":
                    intent = new Intent(v.getContext(), CreateTripActivity.class);
                    break;

                case "My Trips":
                    intent = new Intent(v.getContext(), MyTripsActivity.class);
                    break;

                case "Journal":
                    intent = new Intent(v.getContext(), JournalActivity.class);
                    break;

                case "Explore":
                    intent = new Intent(v.getContext(), ExploreActivity.class);
                    break;
            }

            if (intent != null) {
                v.getContext().startActivity(intent);
            }

        });
    }

    @Override
    public int getItemCount() {
        return actionList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView icon;
        TextView title;

        ViewHolder(View itemView) {
            super(itemView);

            icon = itemView.findViewById(R.id.imgAction);
            title = itemView.findViewById(R.id.txtAction);
        }
    }
}

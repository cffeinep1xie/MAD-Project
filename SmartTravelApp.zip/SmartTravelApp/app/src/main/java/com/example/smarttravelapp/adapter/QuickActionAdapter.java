package com.example.smarttravelapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smarttravelapp.R;
import com.example.smarttravelapp.model.QuickAction;

import java.util.ArrayList;
import android.content.Intent;
import com.example.smarttravelapp.CreateTripActivity;

public class QuickActionAdapter extends RecyclerView.Adapter<QuickActionAdapter.ViewHolder> {

    private final ArrayList<QuickAction> actionList;

    public QuickActionAdapter(ArrayList<QuickAction> actionList) {
        this.actionList = actionList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_quick_action, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        QuickAction action = actionList.get(position);

        holder.icon.setImageResource(action.getIcon());
        holder.title.setText(action.getTitle());

        holder.itemView.setOnClickListener(v -> {

            switch (action.getTitle()) {

                case "Create Trip":
                    Intent intent = new Intent(v.getContext(), CreateTripActivity.class);
                    v.getContext().startActivity(intent);
                    break;

                case "Budget":
                    // TODO: Open Budget Activity
                    break;

                case "Journal":
                    // TODO: Open Journal Activity
                    break;

                case "Explore":
                    // TODO: Open Explore Activity
                    break;
            }
        });
    }

    @Override
    public int getItemCount() {
        return actionList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView icon;
        TextView title;

        ViewHolder(View itemView) {
            super(itemView);

            icon = itemView.findViewById(R.id.imgAction);
            title = itemView.findViewById(R.id.txtAction);
        }
    }
}

package com.example.smarttravelapp;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_TIME = 2500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        SharedPreferences preferences =
                getSharedPreferences("UserSession", MODE_PRIVATE);

        boolean isLoggedIn = preferences.getBoolean("isLoggedIn", false);

        new Handler().postDelayed(() -> {

            Intent intent;

            if (isLoggedIn) {
                intent = new Intent(SplashActivity.this, WelcomeBackActivity.class);
            } else {
                intent = new Intent(SplashActivity.this, LoginActivity.class);
            }

            startActivity(intent);
            finish();

        }, 2500);
    }
}
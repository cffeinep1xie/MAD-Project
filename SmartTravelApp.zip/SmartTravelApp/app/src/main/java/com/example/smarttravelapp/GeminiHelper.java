package com.example.smarttravelapp;

import okhttp3.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

public class GeminiHelper {

    // Replace with your API Key
    private static final String API_KEY =
            "AQ.Ab8RN6JCTk7Ak_mdiImtwpIM4jvlNliOIjMMGADa-mpWSFaHow";

    private static final String URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;
    public interface GeminiCallback {
        void onSuccess(String response);
        void onFailure(String error);
    }

    public static void generateReview(String destination,
                                      GeminiCallback callback) {

        OkHttpClient client = new OkHttpClient();

        try {

            JSONObject body = new JSONObject();

            JSONArray contents = new JSONArray();

            JSONObject content = new JSONObject();

            JSONArray parts = new JSONArray();

            JSONObject part = new JSONObject();

            part.put("text",

                    "You are an expert travel guide.\n\n" +

                            "For the destination " + destination + "\n\n" +

                            "Return ONLY this format.\n\n" +

                            "Rating: 4.8/5\n" +

                            "Summary: (maximum 80 words)\n" +

                            "Highlight1:\n" +

                            "Highlight2:\n" +

                            "Highlight3:\n" +

                            "Highlight4:\n"

            );

            parts.put(part);

            content.put("parts", parts);

            contents.put(content);

            body.put("contents", contents);

            RequestBody requestBody =
                    RequestBody.create(
                            body.toString(),
                            MediaType.parse("application/json"));

            Request request = new Request.Builder()

                    .url(URL)

                    .post(requestBody)

                    .build();

            client.newCall(request).enqueue(new Callback() {

                @Override
                public void onFailure(Call call, IOException e) {

                    callback.onFailure(e.getMessage());

                }

                @Override
                public void onResponse(Call call,
                                       Response response)
                        throws IOException {

                    if (!response.isSuccessful()) {

                        callback.onFailure(
                                "HTTP " + response.code() +
                                        "\n\n" +
                                        response.body().string()
                        );

                        return;
                    }

                    String json = response.body().string();

                    try {

                        JSONObject object =
                                new JSONObject(json);

                        JSONArray candidates =
                                object.getJSONArray("candidates");

                        JSONObject candidate =
                                candidates.getJSONObject(0);

                        JSONObject content =
                                candidate.getJSONObject("content");

                        JSONArray parts =
                                content.getJSONArray("parts");

                        String text =
                                parts.getJSONObject(0)
                                        .getString("text");

                        callback.onSuccess(text);

                    }

                    catch (Exception e) {

                        callback.onFailure(e.getMessage());

                    }

                }

            });

        }

        catch (Exception e) {

            callback.onFailure(e.getMessage());

        }

    }

}
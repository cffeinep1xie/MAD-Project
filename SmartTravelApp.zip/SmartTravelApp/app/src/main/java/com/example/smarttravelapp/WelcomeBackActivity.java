package com.example.smarttravelapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeBackActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_back);

        TextView tvName = findViewById(R.id.tvName);

        SharedPreferences preferences =
                getSharedPreferences("UserSession", MODE_PRIVATE);

        String name = preferences.getString("name", "Traveler");

        tvName.setText(name);

        new Handler().postDelayed(() -> {

            startActivity(new Intent(
                    WelcomeBackActivity.this,
                    MainActivity.class));

            finish();

        }, 2000);

    }
}